# 3. Background and Related Work

## 3.1 Overview of Clustering in Wireless Sensor Networks
Clustering has long been recognized as one of the most effective techniques for organizing Wireless Sensor Networks (WSNs) to achieve energy efficiency and scalability. The fundamental principle of clustering involves partitioning the sensor nodes into groups, or clusters, each led by a designated node known as the Cluster Head (CH). While member nodes are responsible for sensing the environment and transmitting data to their respective CHs, the CHs undertake the more energy-intensive tasks of aggregate data processing and relaying the summarized information to the Base Station (BS).

Despite decades of research, many legacy clustering protocols suffer from a fundamental reliance on probabilistic models for CH selection. This reliance introduces significant volatility in network performance, often leading to uneven energy dissipation—a precursor to the "Energy Hole Problem." In this section, we provide a critical analysis of the three seminal protocols that define the current landscape: LEACH, HEED, and PEGASIS. We examine their structural strengths and, more importantly, the inherent limitations that Vanguard-WSN seeks to overcome through a deterministic utility framework.

## 3.2 LEACH: Low-Energy Adaptive Clustering Hierarchy
### 3.2.1 Probabilistic Foundation
The LEACH protocol, introduced by Heinzelman et al., is the progenitor of modern clustering logic. Its primary innovation was the use of "randomized rotation" of the Cluster Head role. Each node independently decides whether to become a CH based on a threshold value $T(n)$, calculated as follows:
$$T(n) = \frac{p}{1 - p \times (r \mod \frac{1}{p})}$$
where $p$ is the desired percentage of CHs and $r$ is the current round. This mechanism ensures that every node eventually acts as a CH, spreading the higher energy consumption associated with the role across the entire network.

### 3.2.2 Critical Limitations of Probabilistic Rotation
While elegant in its simplicity, LEACH’s probabilistic approach has several critical flaws:
1.  **Agnosticism to Local Conditions:** A node in LEACH decides to become a CH without any knowledge of its residual energy or the energy states of its neighbors. This leads to scenarios where a dying node (with near-zero energy) is selected as a CH. In such cases, the entire cluster’s data is effectively lost because the CH lacks the energy to perform even basic transmission.
2.  **Unbalanced CH Distribution:** Because the selection is independent and randomized, there is a statistical probability that all CHs are located in one corner of the field, leaving nodes in the opposite corner to transmit over extremely long distances. This spatial imbalance causes rapid energy depletion in peripheral nodes, contrary to the goal of uniform energy distribution.
3.  **The "Blind" Rotation Problem:** The rotation logic is strictly tied to the round number, not the actual work performed (traffic load). This means a node that handled a massive cluster in round 5 is just as likely to be selected as a CH in round $5+1/p$ as a node that handled no traffic. LEACH fails to account for the "debt" of energy incurred by heavy traffic loads.

### 3.2.3 Extension: LEACH-C and Centralized Weaknesses
While Centralized LEACH (LEACH-C) attempted to solve the distribution problem by using the sink to select CHs, it introduced a new dependency on global knowledge and high-energy control packets. LEACH-C still lacks the dynamic adaptability of Vanguard-WSN, as it uses a static energy-based sorting that doesn't account for the evolving multi-hop relay burden.

## 3.3 HEED: Hybrid Energy-Efficient Distributed Clustering
### 3.3.1 Iterative Energy Awareness
HEED was proposed as an improvement over LEACH to introduce actual energy awareness into the selection process. It selects CHs through an iterative process based on two primary metrics: residual energy and intra-cluster communication cost (AMRP). A node starts with an initial probability of becoming a CH proportional to its residual energy ($E_{res} / E_{max}$) and iteratively increases its candidacy probability until a stable set of CHs is formed.

### 3.3.2 Computational and Communication Overhead
While HEED provides better CH distribution than LEACH, it introduces new challenges:
1.  **Control Packet Explosion:** The iterative nature of HEED requires multiple rounds of message exchanges (broadcasts, acknowledgments, final announcements) within each setup phase. In high-density WSNs, the energy spent on "deciding" who will be the leader often exceeds the energy saved by the resulting hierarchy.
2.  **Latency and Convergence:** The delay introduced by the multi-pass setup makes HEED less suitable for time-critical monitoring applications. In some scenarios, the network field might change or a critical event might occur while nodes are still stuck in the iteration phase.
3.  **Sensitivity to Initial Parameters:** The performance of HEED is highly dependent on the "cost" metric chosen. If the metric is poorly tuned to the physical topology (e.g., ignoring multi-hop relay burdens outside the cluster), the protocol can still fail to balance the global relay load.

Vanguard-WSN simplifies this by utilizing a **Single-Pass Deterministic Selection**. By using a composite utility score ($U_i = \alpha E_{res} + \beta \text{Density}$), Vanguard-WSN achieves the energy-awareness of HEED without the iterative overhead.

## 3.4 PEGASIS: Power-Efficient Gathering in Sensor Information Systems
### 3.4.1 Chain-Based Data Collection
PEGASIS takes a radically different approach to clustering. Instead of forming stars/clusters, it organizes all nodes into a single linear chain. Each node only communicates with its two closest neighbors, forming a structure that minimizes the total transmission distance across the entire network. Only one node in the chain—the leader—transmits to the Base Station in any given round.

### 3.4.2 The Bottlenecks of Linear Topology
The linear nature of PEGASIS leads to several vulnerabilities:
1.  **Excessive End-to-End Delay:** In a 100-node network, data from the first node must hop through 99 intermediate nodes before reaching the leader. This makes PEGASIS unusable for real-world environmental monitoring (e.g., forest fire detection) where data freshness is key.
2.  **Single Point of Failure (SPOF):** If any node in the chain dies or fails, the entire network is partitioned. The cost of reconstructing the chain is high, requiring global knowledge of node positions. Frequent reconstructions due to node deaths significantly reduce the effective network lifetime.
3.  **The "Leader Fatigue" Problem:** Similar to LEACH, unless the leader selection is incredibly precise, the node responsible for the long-range transmission to the BS will die quickly, and the "hole" in the chain will propagate faster than in a cluster-based system.

Vanguard-WSN’s **EBPT (Energy-Balanced Path Tree)** combines the distance-minimization strengths of PEGASIS with the robustness of clustering. By forming a tree instead of a chain, Vanguard-WSN reduces delay to $O(\log N)$ or $O(\sqrt{N})$ while providing multiple redundant paths for data delivery.

## 3.5 Literature Gaps: The Missing Link in Adaptive Routing
Current literature has seen a surge in "intelligent" clustering protocols, but most remain trapped in the "Local Optimization Trap." 

### 3.5.1 The Local Optimization Trap
Most protocols optimize the "Clustering Phase" or the "Routing Phase" in isolation. For example, a protocol might select excellent CHs but then use a naive shortest-path routing algorithm to reach the sink. This creates the "Energy Hole" because the CHs near the sink—no matter how high their initial energy—cannot survive the aggregate relay burden of the entire network.

### 3.5.2 Lack of Theoretical Anchoring
Another major gap is the lack of benchmarking against theoretical optimal bounds. Many papers report "50% improvement over LEACH" without mentioning that LEACH is performing at only 10% of the possible optimum. Without the "God-Line" (LP Bound) introduced in Section 2, it is impossible to know if a protocol is truly "good" or just "less bad" than baseline LEACH.

## 3.6 Transition to Deterministic Utility: The Vanguard Paradigm
The critical failure of probabilistic rotation is the assumption that randomness leads to fairness. In reality, randomness in energy-constrained systems leads to "Hotspots."

### 3.6.1 Merit-Based Leadership
The Vanguard Framework establishes a new paradigm: **Utility-Driven Determinism**. Our framework operates on the principle that node roles should be a predictable function of state. We replace the probabilistic $T(n)$ with a deterministic Utility Index $U_i$ that incorporates:
- **Residual Energy Ratio:** Identifying nodes with the fuel to lead.
- **Local Node Density:** Ensuring CHs are in "useful" locations for their members.
- **Relay Burden Awareness:** Considering how many nodes potentially rely on this node for multi-hop paths.

### 3.6.2 Addressing the "Funneling Effect"
Vanguard-WSN accounts for the "Funneling Effect" (Energy Hole) by integrating the routing cost into the topology and selection phases. Traditional ad-hoc concepts are bridged to WSNs by acknowledging that while nodes are stationary, the "energy terrain" is highly dynamic. A node that was a "safe" relay in Round 1 becomes a "critical" relay in Round 500. Vanguard-WSN’s adaptive $\gamma$ factor ensures that the network "tree" breathes and reconfigures to bypass these critical relays before they die.

## 3.7 Comparisons and Categorization
To contextualize our work, we categorize WSN protocols into four generations:
1.  **First Generation (Direct/Probabilistic):** Direct Transmission, LEACH. (Strength: Simple; Weakness: Rapid Hole formation).
2.  **Second Generation (Energy-Aware Local):** HEED, TEEN, APTEEN. (Strength: Local Energy Balance; Weakness: High setup overhead).
3.  **Third Generation (Structure-Based):** PEGASIS, V-LEACH. (Strength: Transmission optimization; Weakness: High delay).
4.  **Fourth Generation (Vanguard/Utility-Driven):** EBPT-CRA, Vanguard-WSN. (Strength: Global energy-load balancing, Theoretical Alignment).

### 3.7.1 Reliability, Fault Tolerance, and Self-Healing
A critical often-overlooked aspect of clustering protocols is their resilience to individual node failures. In a harsh deployment environment, sensor nodes are susceptible to physical damage, battery exhaustion, or communication interference. Traditional protocols like PEGASIS and single-hop LEACH have very low fault tolerance; a single failure in the chain or a CH failure mid-round results in significant data loss for the entire cluster. 

Vanguard-WSN introduces a "self-healing" capability through its dynamic EBPT construction. Because the controller is aware of the alive status of all nodes at the start of each round, it can immediately route around failed nodes. Furthermore, by using a multi-hop tree instead of a static chain, Vanguard-WSN ensures that the failure of a single relay node only affects the subtree rooted at that node, and even then, the child nodes can quickly reattach to an alternative parent in the next round. This combination of deterministic selection and structural flexibility provides a "safety net" that is missing from probabilistic rotation schemes.
| Feature | LEACH | HEED | PEGASIS | **Vanguard-WSN** |
| :--- | :--- | :--- | :--- | :--- |
| **Selection Type** | Probabilistic | Energy-Iterative | Distance-Greedy | **Deterministic Utility** |
| **Topology** | Cluster (Star) | Cluster (Hierarchical) | Chain | **Energy-Balanced Tree** |
| **Energy Awareness** | None | Local | Local | **Global (via EBPT)** |
| **Overhead** | Low | High | Medium | **Optimized Low** |
| **Reliability** | Low | Medium | High (Distance) | **High (Multi-path)** |
| **Delay** | Low | Medium | High | **Medium-Low** |
| **Scalability** | Low | Medium | Low | **High** |

By synthesizing the lessons learned from these seminal protocols and explicitly addressing the "blind spots" of probabilistic rotation, Vanguard-WSN provides a robust, scalable, and mathematically grounded framework. The 10.21x lifetime improvement reported in Section 6 is not an accident of simulation but the direct result of replacing randomness with deterministic, utility-driven intelligence.
