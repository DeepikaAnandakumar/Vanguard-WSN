import os
import re
from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH

def convert_md_to_docx(md_path, docx_path, figure_dir):
    print(f"Starting conversion: {md_path} -> {docx_path}")
    
    doc = Document()
    
    # Set default styles
    style = doc.styles['Normal']
    font = style.font
    font.name = 'Times New Roman'
    font.size = Pt(11)
    
    # Ensure headings also use Times New Roman
    for i in range(4):
        style_name = f'Heading {i}' if i > 0 else 'Title'
        if style_name in doc.styles:
            h_style = doc.styles[style_name]
            h_style.font.name = 'Times New Roman'
            h_style.font.bold = True
            if i == 0:
                h_style.font.size = Pt(16)
            else:
                h_style.font.size = Pt(14 - i)

    if not os.path.exists(md_path):
        print(f"Error: {md_path} not found.")
        return

    with open(md_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    current_table = None
    in_code_block = False
    
    for line in lines:
        line_clean = line.strip()
        
        # Handle Code Blocks (for Algorithms)
        if line_clean.startswith('```'):
            in_code_block = not in_code_block
            continue
            
        if in_code_block:
            p = doc.add_paragraph(line_clean)
            if 'No Spacing' in doc.styles:
                p.style = doc.styles['No Spacing']
            run = p.runs[0] if p.runs else p.add_run(line_clean)
            run.font.name = 'Courier New'
            run.font.size = Pt(9)
            continue

        # Handle Tables (Markdown style)
        if '|' in line_clean and line_clean.count('|') >= 2:
            if '---' in line_clean:
                continue # Skip the markdown separator line
                
            parts = [p.strip() for p in line_clean.split('|')]
            if not parts[0]: parts = parts[1:]
            if not parts[-1]: parts = parts[:-1]
            
            if not parts:
                continue

            # Start of a new table or continuing one
            if current_table is None:
                current_table = doc.add_table(rows=0, cols=len(parts))
                current_table.style = 'Table Grid'
            
            row = current_table.add_row()
            for i, text in enumerate(parts):
                if i < len(row.cells):
                    row.cells[i].text = text.replace('**', '') 
            continue 
        else:
            current_table = None

        # Handle Headings
        if line_clean.startswith('# '):
            p = doc.add_heading(line_clean[2:], level=0)
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        elif line_clean.startswith('## '):
            doc.add_heading(line_clean[3:], level=1)
        elif line_clean.startswith('### '):
            doc.add_heading(line_clean[4:], level=2)
            
        # Handle Figures (Support all 10)
        elif "Figure" in line_clean and (".png" in line_clean or "referencing" in line_clean):
            match = re.search(r'figure\d+_\w+\.png', line_clean)
            if match:
                fig_filename = match.group(0)
                doc.add_paragraph(line_clean, style='Caption')
                img_path = os.path.join(figure_dir, fig_filename)
                if os.path.exists(img_path):
                    doc.add_picture(img_path, width=Inches(5.0))
                    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
                else:
                    print(f"Warning: {img_path} not found.")
                continue

        # Handle Paragraphs
        elif line_clean:
            if not line_clean.startswith('!['):
                p = doc.add_paragraph()
                
                # Math centering logic
                if line_clean.startswith('$$') and line_clean.endswith('$$'):
                    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    line_clean = line_clean[2:-2]
                
                # Bold conversion
                parts = re.split(r'(\*\*.*?\*\*)', line_clean)
                for part in parts:
                    if part.startswith('**') and part.endswith('**'):
                        run = p.add_run(part[2:-2])
                        run.bold = True
                    else:
                        p.add_run(part)
        else:
            pass

    doc.save(docx_path)
    print(f"Success! Saved to {docx_path}")

if __name__ == "__main__":
    import sys
    BASE_DIR = r"c:\Users\Lenovo\OneDrive\Desktop\6TH SEM\case study\case study"
    FIGURE_DIR = os.path.join(BASE_DIR, "_final_submission_", "project_figures")
    
    if len(sys.argv) > 2:
        MD_INPUT = sys.argv[1]
        DOCX_OUTPUT = sys.argv[2]
    else:
        # Default to Introduction
        MD_INPUT = os.path.join(BASE_DIR, "springer_paper", "Introduction.md")
        DOCX_OUTPUT = os.path.join(BASE_DIR, "springer_paper", "Introduction.docx")
    
    convert_md_to_docx(MD_INPUT, DOCX_OUTPUT, FIGURE_DIR)
