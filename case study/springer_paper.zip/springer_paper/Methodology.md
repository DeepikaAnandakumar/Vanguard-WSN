# 4. Methodology: Utility-Driven Path Selection

## 4.1 Introduction to the Vanguard Methodology
The effectiveness of a Wireless Sensor Network (WSN) in long-term environmental monitoring is predicated on its ability to manage its energy resources with extreme precision. As discussed in previous sections, legacy protocols rely on probabilistic models that often lead to "energy hotspots" and early network partition. The Vanguard Framework introduces a new methodology rooted in **Utility-Driven Determinism**. 

Our methodology shifts the focus from "randomized rotation" to "merit-based leadership." We propose that the selection of Cluster Heads (CHs) and the construction of routing paths should be a deterministic function of a node's physical state—specifically its residual energy, its local topological density, and its current traffic load. In this section, we provide the mathematical derivation of our utility function, present the algorithmic logic of the Energy-Balanced Path Tree (EBPT), and explain how this framework closes the "God-Line Gap" identified in Section 2.

## 4.2 Mathematical Foundation: Energy-Density Utility
The core of the Vanguard Framework is the **Utility Index ($U_i$)**. This index is a composite score assigned to each node $i$ during the setup phase of every simulation round. 

### 4.2.1 The Utility Function Formula
Instead of utilizing complex evidence theories like D&SMR or subjective "Trust Scores," Vanguard employs a more objective and physically grounded metric:
$$U_i = \alpha \left(\frac{E_{res, i}}{E_{max, i}}\right) + \beta \left(\frac{1}{1 + \text{deg}(i)}\right)$$
In this formulation:
- $E_{res, i}$ is the current residual energy of node $i$.
- $E_{max, i}$ is the initial total energy assigned to node $i$.
- $\text{deg}(i)$ is the local node density, defined as the number of active neighbors within the communication range $R_c$.
- $\alpha$ and $\beta$ are weighting factors, typically balanced such that $\alpha + \beta = 1$.

### 4.2.2 Rationale for Energy Weight ($\alpha$)
The term $\frac{E_{res, i}}{E_{max, i}}$ ensures that nodes with higher energy levels are significantly more likely to assume the Cluster Head role. Unlike LEACH, which might select a node with 1% energy simply because its "random number" was low, Vanguard ensures that a node with 1% energy will have a $U_i$ close to zero, effectively removing it from the leadership pool. This preserves the remaining energy of dying nodes for low-power sensing operations rather than high-power relaying.

### 4.2.3 Rationale for Density Weight ($\beta$)
The term $\frac{1}{1 + \text{deg}(i)}$ is critical for structural efficiency. In a WSN, nodes in high-density areas (clusters) benefit from having a CH that is centrally located. However, if multiple nodes are crowded together, selecting one as a CH and having the others act as members is more efficient than having several nodes in close proximity all acting as CHs. The density factor inversely affects the utility; nodes in extremely sparse areas (where $\text{deg}(i)$ is low) receive a utility boost, encouraging the formation of clusters in the network periphery, which are often neglected in standard protocols.

## 4.3 Algorithm 1: Utility-Based CH Selection
The CH selection process in Vanguard-WSN is centralized at the SDN (Software Defined Network) controller at the Base Station but implemented locally through broadcast updates. This ensures that the global topology is maintained while reducing the control packet overhead seen in iterative protocols like HEED.

### 4.3.1 Selection Logic
```text
Algorithm 1: Utility-Based CH Selection
1. State Reporting: At the beginning of the setup phase, each node transmits a short heartbeat packet containing its ID and E_res.
2. Utility Calculation: The controller (or the nodes themselves in a semi-distributed mode) calculates U_i for all alive nodes.
3. Thresholding: A node i is selected as a CH if U_i > tau, where tau is a dynamic threshold and the node has not acted as a CH for a specific number of rounds (to ensure some long-term fairness).
4. Candidacy Broadcast: Selected nodes broadcast a CH_ADV advertisement.
5. Cluster Join: Non-CH nodes join the CH with the highest U_i and the strongest link quality (RSSI), ensuring that the resulting clusters are both energy-efficient and structurally sound.
```

### 4.3.2 Comparison with LEACH-C
While LEACH-C also uses a centralized approach, it uses a simple energy-based sorting. Vanguard’s $U_i$ is multi-dimensional. By incorporating $\text{deg}(i)$, Vanguard avoids the "CH overcrowding" problem where several CHs are selected in a single small area, a common failure point that leads to inter-cluster interference and redundant transmission costs.

## 4.4 The Energy-Balanced Path Tree (EBPT)
Once clusters are formed, the next challenge is routing the aggregated data to the Base Station. In Vanguard-WSN, this is achieved through the **Energy-Balanced Path Tree (EBPT)**. 

### 4.4.1 EBPT Construction Logic
The EBPT is a multi-hop relay structure rooted at the Base Station. The construction follows a greedy energy-balanced approach:
1.  **Distance Sorting:** Nodes (and CHs) are sorted by their Euclidean distance to the Base Station.
2.  **Parent Selection:** Starting from the nodes closest to the BS, each node $u$ searches for a parent $v$ in its candidate set (nodes already in the tree or the BS itself).
3.  **Weighted Edge Cost:** Instead of choosing the absolute shortest path, node $u$ selects parent $v$ that maximizes the following edge weight:
    $$\text{Weight}(u, v) = \frac{\text{EnergyScore}(v)}{1.0 + \gamma \times \text{Load}(v)}$$
    where $\text{Load}(v)$ is the number of children node $v$ is already supporting in the current round.

### 4.4.2 The Role of the Adaptive $\gamma$ Factor
The $\gamma$ (Gamma) factor is the "intelligence" of the EBPT. It controls the trade-off between energy efficiency and load balancing:
- **Low $\gamma$ ($\gamma \to 0$):** The routing behaves like a standard shortest-path tree. This is efficient in the early rounds when energy is abundant.
- **High $\gamma$ ($\gamma > 0$):** The routing heavily penalizes nodes with high loads. This forces the tree to "spread out," using alternative relays even if they are slightly further away, thus preventing the "Energy Hole" from forming at the nodes closest to the BS.

The Vanguard framework uses an **Adaptive Gamma Tuner** that increases $\gamma$ as the network-wide energy variance increases. When the network starts to show signs of "asymmetric depletion," the tuner boosts $\gamma$, forcing the EBPT to reconfigure into a more balanced state.

## 4.5 Why This Resets the D&SMR and Trust-Score Paradigms
Many contemporary research papers attempt to use "Trust Scores" or "Evidence Theory" (like Dempster-Shafer) to decide CH roles. These methods are often motivated by the need to handle "uncertainty" in the network. For instance, the D&SMR (Dempster-Shafer Evidence Theory for Multi-hop Routing) attempts to combine multiple criteria like energy, delay, and reliability using a "Belief Function" that assigns probabilities to various hypotheses about a node's suitability.

### 4.5.1 Simplifying the Decision Layer
"Trust" in a static, honest WSN is effectively a proxy for "Availability" and "Efficiency." While D&SMR is powerful, it carries a heavy mathematical overhead. Every time evidence is combined, the complexity grows, often requiring sensor nodes to perform matrix-like operations that significantly drain battery. Vanguard-WSN replaces this "belief" with "certainty." By focusing purely on Energy and Density, we remove the subjective layer of evidence combination. We prove that a deterministic utility function, if correctly tuned, out-performs evidence-based systems because it acts directly on the physical inhibitors of network lifetime rather than an abstracted score. 

### 4.5.2 Closing the God-Line Gap: A Concrete Example
Consider a scenario where three nodes are competing to be a CH. Node A has high energy but is in a sparse area. Node B has medium energy but is in a dense area. Node C has low energy but is centrally located.
- **Probabilistic LEACH** might pick Node C based on a roll of the dice, leading to a cluster failure mid-round.
- **Evidence-based D&SMR** would spend multiple packets trying to weigh the "evidence" for each node, depleting all three.
- **Vanguard** immediately calculates $U_i$. Node A’s high energy is weighed against its low density utility. If $\alpha=0.6$ and $\beta=0.4$, Node A’s energy might carry it to leadership, ensuring the longest possible cluster life. If Node A's energy drops, the $U_i$ automatically pivots to Node B. This "smooth transition" is what keeps the empirical performance line glued to the theoretical God-Line for hundreds of rounds longer than any legacy protocol.

## 4.6 Algorithmic Complexity and Scalability
The computational complexity of constructing the EBPT and selecting CHs is $O(N \log N)$ due to the sorting requirements. In a network of $N$ nodes, sorting by distance and kemudian iterating through the list to find the "max weight" parent is efficient. For a standard WSN deployment with $N=100$ to $N=500$ nodes, this calculation is trivial for modern base station hardware. Furthermore, since the logic is centralized at the SDN controller, the sensor nodes are spared the complex iterative calculations, further preserving their limited battery life.

## 4.7 Traffic-Aware Congestion Avoidance in EBPT
A "Methodology" section on Vanguard would be incomplete without discussing the integration of traffic models. Each packet generated by a node $i$ adds to the cumulative Load of its ancestors in the EBPT.

### 4.7.1 Modeling Cumulative Load
Traditional trees only care about the distance to the next hop. However, the energy cost of a node $v$ is not just its own transmission but the power required to receive, store, and aggregate data from all its descendants. Vanguard-WSN models this as:
$$\text{Load}(v) = \sum_{j \in \text{Children}(v)} (1 + \text{Load}(j))$$
Our methodology ensures that when node $u$ is looking for a parent, it "interrogates" the controller for the potential load on node $v$. If $v$ is already the ancestor of 20 nodes, its load factor makes the denominator in our weight function so high that $v$ becomes "repulsive" to new nodes, regardless of its residual energy.

### 4.7.2 Quantifying the Congestion Penalty
By using the load-aware denominator $(1.0 + \gamma \times \text{Load}(v))$, we effectively implement a **Greedy Multi-Objective Optimization**. The algorithm seeks to maximize energy while minimizing congestion. This is particularly effective in event-driven WSNs where a localized "event" (like a sudden temperature spike) causes a burst of traffic in one specific area. Standard protocols would succumb to congestion-induced energy exhaustion in that area; Vanguard-WSN simply "bends" the tree around the congestion zone, distributing the burden across nodes that were previously idle.

## 4.8 Adaptive Weight Tuning ($\alpha$ and $\beta$)
While we have defined the $U_i$ formula, the selection of $\alpha$ and $\beta$ is not static. Our methodology includes a **Phase-Shifting Strategy**:
1.  **Exploration Phase (Early Rounds):** $\beta > \alpha$. We prioritize a good distribution of CHs to explore the network sensing potential.
2.  **Exploitation Phase (Late Rounds):** $\alpha > \beta$. We prioritize residual energy above all else as the network begins to show signs of depletion.

This phase-shifting is controlled by the SDN controller, which monitors the global energy variance. When the variance exceeds a threshold $\sigma_{crit}$, the controller broadcasts an update to the weight parameters, essentially "re-programming" the network's behavior in real-time. This level of dynamic control is a hallmark of the Vanguard framework and is the primary reason it can handle the transition from a dense to a sparse network without a significant drop in data delivery performance.

## 4.9 Summary of the Methodology
In summary, the Vanguard Framework methodology is defined by three pillars:
1.  **Deterministic CH Selection:** Using the Energy-Density Utility Index $U_i$ to ensure leadership based on physical merit.
2.  **Dynamic Hierarchy:** Using the EBPT to provide multi-hop paths that avoid energy holes.
3.  **Adaptive Tunability:** Using the $\gamma$ factor and the $(\alpha, \beta)$ weights to balance the global load as the network energy landscape evolves.

The combination of these elements provides a self-sustaining architecture that maximizes the utility of every joule stored in the network, paving the way for the breakthrough results detailed in the Experimental Analysis.
