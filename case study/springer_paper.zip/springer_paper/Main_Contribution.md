# 2. Main Contribution (Vanguard Framework)

## 2.1 Motivation: Bridging the Theoretical God-Line Gap
The primary motivation behind the development of the Vanguard-WSN framework is the significant disparity between the theoretical maximum lifetime of a Wireless Sensor Network (WSN) and the empirical performance achieved by state-of-the-art heuristic protocols. In the academic literature, this theoretical limit is often referred to as the "God-Line"—the upper bound of network longevity that could be achieved if an omniscient controller had perfect foresight of every packet transmission and could balance the energy load with infinite precision across all nodes.

### 2.1.1 Defining the God-Line
The God-Line is derived using a Network Utility Maximization (NUM) framework, typically solved via Linear Programming (LP). By formulating the network lifetime $T$ as an objective function to be maximized subject to flow conservation and hardware-specific energy constraints, we establish a benchmark that is independent of any specific routing protocol or clustering algorithm. Our research indicates that standard protocols like LEACH and HEED often perform at only 10-15% of this theoretical maximum. This massive "performance gap" is primarily due to the localized nature of their decision-making. These protocols optimize for the next round or the nearest neighbor, whereas the God-Line assumes a holistic optimization over the entire network duration.

### 2.1.2 The Vanguard Philosophy
Vanguard-WSN is engineered to close this gap. Instead of relying on randomized or purely local metrics, Vanguard introduces a utility-driven methodology that approximates the global optimization of the LP bound through distributed heuristics. We recognize that the "Energy Hole Problem" identified in Section 1 is not just a routing failure but a lack of structural awareness. The Vanguard Framework seeks to provide this awareness by embedding energy-balancing logic into every layer of the network stack, from the initial cluster formation to the final delivery of data at the Base Station.

## 2.2 The Energy-Balanced Path Tree (EBPT) Architecture
At the core of the Vanguard Framework is the Energy-Balanced Path Tree (EBPT). This is a dynamic, multi-hop routing structure that reconfigures itself in every simulation round to ensure that no single node or group of nodes is overburdened. Unlike traditional trees that prioritize the minimum number of hops (which leads to the depletion of nodes near the sink), the EBPT prioritizes nodes with high residual energy and low current traffic load.

**Figure 3: EBPT Routing Tree** (referencing `figure3_routing_tree.png`) illustrates this sophisticated hierarchy. In this snapshot, we observe how leaf nodes (the sensing endpoints) do not transmit directly to the Base Station. Instead, they intelligently select a Cluster Head (CH) based on link quality and the CH's residual energy. These CHs then form a secondary "backbone" tree, relaying their aggregated data through other intermediate nodes or higher-tier CHs until the data reaching the Base Station. This multi-hop relaying is not static; as a particular relay node’s energy drops below a critical threshold, the EBPT logic automatically reroutes the traffic through a "fresher" path, effectively distributing the relaying cost across the entire network topology.

## 2.3 System Model and Assumptions
To ensure the reproducibility and rigorous validation of the Vanguard Framework, we define a comprehensive system model that reflects the physical realities of modern WSN deployments.

### 2.3.1 Network Topology Model
We consider a network of $N$ sensor nodes (typically $N=100$ in our primary scenarios) deployed randomly in a $100m \times 100m$ square monitoring field. The Base Station is positioned at the center of the field ($50, 50$), creating a balanced distribution of distances. All nodes are assumed to be quasi-stationary after deployment. The communication environment is modeled using the First-Order Radio Model, which accounts for both transmitter/receiver electronics and the power amplifier cost based on distance $d$.

### 2.3.2 Energy Dissipation Model
Vanguard-WSN utilizes a two-tier energy cost model:
1.  **Free Space Propagation ($d < d_0$):** Energy cost scales with $d^2$.
2.  **Multipath Fading ($d \ge d_0$):** Energy cost scales with $d^4$.

The threshold distance $d_0$ is approximately 87 meters, derived from the ratio of transmitter parameters. Our model specifically includes the energy cost of Data Aggregation ($E_{DA}$), which is critical for hierarchical protocols. When a CH receives data from its cluster members, it compresses the multiple packets into a single summary packet before relaying it up the EBPT. This aggregation significantly reduces the total bit-count transmitted over the expensive long-range links, contributing to the 10x lifetime improvement we observe.

### 2.3.3 Traffic and Traffic-Awareness
Each node generates data packets at a constant rate $g_i$. In our "Hybrid_AllFeatures" configuration, the Vanguard framework is also traffic-aware. This means that when constructing the EBPT, the controller considers not just the residual energy but also the expected congestion on a path. If a particular relay node is already handling traffic from ten other nodes, its "cost" in the EBPT weight function increases, encouraging new nodes to seek alternative parents even if the current node has high energy.

## 2.4 Multi-Dimensional Performance Analysis
The superiority of the Vanguard Framework is not limited to a single metric. While network lifetime (FND) is our primary focus, we must also ensure that the network remains fair and reliable throughout its operation.

**Figure 4: Performance Radar Chart** (referencing `figure4_pareto.png`) provides a multi-dimensional view of Vanguard’s performance relative to the LEACH baseline and the theoretical God-Line.
- **Lifetime (FND/LND):** Vanguard-WSN achieves nearly 1,000 rounds of stability, a 10.21x increase over the baseline.
- **Fairness (Jain’s Index):** By employing the load-balancing factor $\gamma$, Vanguard maintains a high degree of energy symmetry among nodes, preventing "hotspots."
- **Reliability (PDR):** The hierarchical tree structure ensures that path failures are rare, and the re-routing capability allows for high Packet Delivery Ratios even as nodes begin to die.
- **Energy Efficiency:** The total energy consumed per successful packet delivery is minimized by avoiding long-range transmissions for basic sensing nodes.

As shown in the radar chart, Vanguard-WSN occupies a much larger "area" of the performance space than traditional protocols. It moves the operational state of the network significantly closer to the "Ideal Performance" vertex, proving that the integration of theoretical optimal bounds into distributed routing logic is a viable and highly effective strategy for the next generation of Wireless Sensor Networks. 

In the following section, we will delve into the specific mathematical weight functions and the submodular optimization proofs that underpin these results.
